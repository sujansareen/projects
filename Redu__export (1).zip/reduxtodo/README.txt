How to run ?

On terminal
- cd react-redux-todo-reduxfinal
- npm install
- npm start


==========================================================================

For other versions of App discussed in the class,
Go to https://github.com/gaurav51289/react-redux-todo

Braches: master - Simple Todo app with React
	 redux - Todo app with Redux with a Flaw
	 reduxfinal - Todo app working with Redux