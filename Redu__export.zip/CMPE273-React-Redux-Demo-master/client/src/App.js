import React, {Component} from 'react';
import Index from './components/index';


    class App extends Component {
        render() {
            return (
                
                <div className="App">
               
                     <Index/>
                 
                </div>
            );
        }
    }

    export default App;
