# CMPE273-React-Redux-Demo
Youtube: <a>https://youtu.be/CnfFL_3MQXM</a>

Run the application:
<ul>Client:
  <li> cd client</li>
  <li>npm start</li></ul>
<ul>Server:
  <li> cd server</li>
  <li>npm start</li></ul>
